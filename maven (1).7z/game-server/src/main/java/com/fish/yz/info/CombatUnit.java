package com.fish.yz.info;

/**
 * Created by fishman on 19/12/2016.
 *
 */
public class CombatUnit extends Unit {

	public CombatUnit(){
		this.initLoad();
	}

}
