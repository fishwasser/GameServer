package com.fish.yz.info;

/**
 * Created by fishman on 19/12/2016.
 *
 */
public class Monster extends CombatUnit {

	public Monster(){
	}

}
