package com.fish.yz;

/**
 * Created by xscn2426 on 2016/12/12.
 * 状态
 */
public enum States {
	ST_NOT_CONNECTED,
	ST_CONNECTING,
	ST_CONNECTED,
}
